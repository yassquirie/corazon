
'use client';

import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header Navigation */}
      <header className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-emerald-700" style={{fontFamily: 'Pacifico, serif'}}>
                Beauté Pure
              </h1>
            </div>
            <nav className="hidden md:flex space-x-8">
              <Link href="/" className="text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
                Accueil
              </Link>
              <Link href="/products" className="text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
                Produits
              </Link>
              <Link href="/about" className="text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
                À propos
              </Link>
              <Link href="/contact" className="text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
                Contact
              </Link>
            </nav>
            <div className="flex items-center space-x-4">
              <button className="w-6 h-6 flex items-center justify-center text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
                <i className="ri-search-line"></i>
              </button>
              <button className="w-6 h-6 flex items-center justify-center text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
                <i className="ri-shopping-cart-line"></i>
              </button>
              <button className="w-6 h-6 flex items-center justify-center text-gray-700 hover:text-emerald-600 transition-colors cursor-pointer">
                <i className="ri-user-line"></i>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-emerald-50 to-rose-50 py-20">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-top"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=elegant%20spa%20environment%20with%20natural%20skincare%20products%2C%20soft%20lighting%2C%20minimal%20clean%20background%20with%20subtle%20green%20and%20pink%20tones%2C%20luxurious%20beauty%20treatment%20setting%2C%20serene%20atmosphere%2C%20high-end%20cosmetics%20display%2C%20professional%20photography%20style&width=1200&height=600&seq=hero-beauty-1&orientation=landscape')`
          }}
        >
          <div className="absolute inset-0 bg-white/40"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="w-full text-center">
            <h2 className="text-5xl font-bold text-gray-800 mb-6">
              Révélez votre beauté naturelle
            </h2>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Découvrez notre collection exclusive de soins du visage naturels et efficaces pour une peau radieuse et éclatante de santé.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/products">
                <button className="bg-emerald-600 text-white px-8 py-3 rounded-full hover:bg-emerald-700 transition-colors whitespace-nowrap cursor-pointer">
                  Découvrir nos produits
                </button>
              </Link>
              <button className="border-2 border-rose-400 text-rose-400 px-8 py-3 rounded-full hover:bg-rose-50 transition-colors whitespace-nowrap cursor-pointer">
                Consultation gratuite
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="text-3xl font-bold text-center text-gray-800 mb-12">
            Nos catégories phares
          </h3>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-gradient-to-b from-emerald-50 to-white rounded-xl p-8 text-center hover:shadow-lg transition-shadow cursor-pointer">
              <div className="mb-6">
                <img
                  src="https://readdy.ai/api/search-image?query=elegant%20face%20cleanser%20bottle%20with%20natural%20ingredients%2C%20minimalist%20packaging%20design%2C%20soft%20green%20and%20white%20colors%2C%20spa-like%20setting%2C%20clean%20background%2C%20professional%20product%20photography&width=300&height=200&seq=cleanser-1&orientation=landscape"
                  alt="Nettoyants"
                  className="w-full h-48 object-cover object-top rounded-lg"
                />
              </div>
              <h4 className="text-xl font-semibold text-gray-800 mb-3">Nettoyants</h4>
              <p className="text-gray-600 mb-4">Purifiez votre peau en douceur avec nos nettoyants naturels adaptés à tous types de peau.</p>
              <Link href="/products">
                <button className="text-emerald-600 font-medium hover:text-emerald-700 transition-colors cursor-pointer">
                  Découvrir →
                </button>
              </Link>
            </div>

            <div className="bg-gradient-to-b from-rose-50 to-white rounded-xl p-8 text-center hover:shadow-lg transition-shadow cursor-pointer">
              <div className="mb-6">
                <img
                  src="https://readdy.ai/api/search-image?query=luxury%20face%20serum%20bottle%20with%20dropper%2C%20rose%20gold%20accents%2C%20elegant%20packaging%2C%20soft%20pink%20and%20white%20background%2C%20beauty%20product%20photography%2C%20minimal%20clean%20aesthetic&width=300&height=200&seq=serum-1&orientation=landscape"
                  alt="Sérums"
                  className="w-full h-48 object-cover object-top rounded-lg"
                />
              </div>
              <h4 className="text-xl font-semibold text-gray-800 mb-3">Sérums</h4>
              <p className="text-gray-600 mb-4">Concentrés d'actifs puissants pour cibler vos préoccupations spécifiques et sublimer votre peau.</p>
              <Link href="/products">
                <button className="text-rose-400 font-medium hover:text-rose-500 transition-colors cursor-pointer">
                  Découvrir →
                </button>
              </Link>
            </div>

            <div className="bg-gradient-to-b from-emerald-50 to-white rounded-xl p-8 text-center hover:shadow-lg transition-shadow cursor-pointer">
              <div className="mb-6">
                <img
                  src="https://readdy.ai/api/search-image?query=premium%20face%20moisturizer%20jar%20with%20natural%20ingredients%2C%20elegant%20cream%20texture%2C%20soft%20lighting%2C%20clean%20white%20and%20green%20packaging%2C%20spa%20environment%2C%20luxury%20skincare%20photography&width=300&height=200&seq=moisturizer-1&orientation=landscape"
                  alt="Crèmes"
                  className="w-full h-48 object-cover object-top rounded-lg"
                />
              </div>
              <h4 className="text-xl font-semibold text-gray-800 mb-3">Crèmes</h4>
              <p className="text-gray-600 mb-4">Hydratez et nourrissez votre peau avec nos crèmes onctueuses aux textures délicates.</p>
              <Link href="/products">
                <button className="text-emerald-600 font-medium hover:text-emerald-700 transition-colors cursor-pointer">
                  Découvrir →
                </button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Best Sellers */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="text-3xl font-bold text-center text-gray-800 mb-12">
            Nos meilleures ventes
          </h3>
          <div className="grid md:grid-cols-4 gap-6">
            <div className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow cursor-pointer">
              <img
                src="https://readdy.ai/api/search-image?query=vitamin%20C%20serum%20bottle%20with%20bright%20orange%20liquid%2C%20professional%20product%20photography%2C%20clean%20white%20background%2C%20modern%20packaging%20design%2C%20skincare%20product%20display&width=250&height=250&seq=vitamin-c-1&orientation=squarish"
                alt="Sérum Vitamine C"
                className="w-full h-48 object-cover object-top rounded-lg mb-4"
              />
              <h4 className="font-semibold text-gray-800 mb-2">Sérum Vitamine C</h4>
              <p className="text-sm text-gray-600 mb-3">Éclat et protection antioxydante</p>
              <div className="flex items-center justify-between">
                <span className="text-lg font-bold text-emerald-600">45€</span>
                <button className="bg-emerald-600 text-white px-4 py-2 rounded-full text-sm hover:bg-emerald-700 transition-colors whitespace-nowrap cursor-pointer">
                  Ajouter
                </button>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow cursor-pointer">
              <img
                src="https://readdy.ai/api/search-image?query=hyaluronic%20acid%20serum%20bottle%20with%20clear%20liquid%2C%20minimalist%20design%2C%20clean%20laboratory%20background%2C%20professional%20skincare%20photography%2C%20modern%20packaging&width=250&height=250&seq=hyaluronic-1&orientation=squarish"
                alt="Sérum Acide Hyaluronique"
                className="w-full h-48 object-cover object-top rounded-lg mb-4"
              />
              <h4 className="font-semibold text-gray-800 mb-2">Sérum Acide Hyaluronique</h4>
              <p className="text-sm text-gray-600 mb-3">Hydratation intense et repulpage</p>
              <div className="flex items-center justify-between">
                <span className="text-lg font-bold text-emerald-600">38€</span>
                <button className="bg-emerald-600 text-white px-4 py-2 rounded-full text-sm hover:bg-emerald-700 transition-colors whitespace-nowrap cursor-pointer">
                  Ajouter
                </button>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow cursor-pointer">
              <img
                src="https://readdy.ai/api/search-image?query=retinol%20cream%20jar%20with%20elegant%20gold%20accents%2C%20luxury%20skincare%20packaging%2C%20sophisticated%20lighting%2C%20clean%20background%2C%20premium%20beauty%20product%20photography&width=250&height=250&seq=retinol-1&orientation=squarish"
                alt="Crème Rétinol"
                className="w-full h-48 object-cover object-top rounded-lg mb-4"
              />
              <h4 className="font-semibold text-gray-800 mb-2">Crème Rétinol</h4>
              <p className="text-sm text-gray-600 mb-3">Anti-âge et renouvellement cellulaire</p>
              <div className="flex items-center justify-between">
                <span className="text-lg font-bold text-emerald-600">55€</span>
                <button className="bg-emerald-600 text-white px-4 py-2 rounded-full text-sm hover:bg-emerald-700 transition-colors whitespace-nowrap cursor-pointer">
                  Ajouter
                </button>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow cursor-pointer">
              <img
                src="https://readdy.ai/api/search-image?query=gentle%20face%20cleanser%20bottle%20with%20natural%20green%20color%2C%20organic%20skincare%20product%2C%20clean%20minimalist%20design%2C%20spa-like%20environment%2C%20professional%20photography&width=250&height=250&seq=cleanser-gentle-1&orientation=squarish"
                alt="Nettoyant Doux"
                className="w-full h-48 object-cover object-top rounded-lg mb-4"
              />
              <h4 className="font-semibold text-gray-800 mb-2">Nettoyant Doux</h4>
              <p className="text-sm text-gray-600 mb-3">Purification délicate quotidienne</p>
              <div className="flex items-center justify-between">
                <span className="text-lg font-bold text-emerald-600">28€</span>
                <button className="bg-emerald-600 text-white px-4 py-2 rounded-full text-sm hover:bg-emerald-700 transition-colors whitespace-nowrap cursor-pointer">
                  Ajouter
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="text-3xl font-bold text-center text-gray-800 mb-12">
            Pourquoi choisir Beauté Pure ?
          </h3>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-leaf-line text-2xl text-emerald-600"></i>
              </div>
              <h4 className="text-xl font-semibold text-gray-800 mb-3">Ingrédients naturels</h4>
              <p className="text-gray-600">Nos produits sont formulés avec des ingrédients naturels et biologiques soigneusement sélectionnés.</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-microscope-line text-2xl text-rose-400"></i>
              </div>
              <h4 className="text-xl font-semibold text-gray-800 mb-3">Recherche avancée</h4>
              <p className="text-gray-600">Nos laboratoires développent des formules innovantes basées sur les dernières recherches scientifiques.</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-heart-line text-2xl text-emerald-600"></i>
              </div>
              <h4 className="text-xl font-semibold text-gray-800 mb-3">Testé dermatologiquement</h4>
              <p className="text-gray-600">Tous nos produits sont testés dermatologiquement et conviennent aux peaux sensibles.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-emerald-600 to-rose-400">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-3xl font-bold text-white mb-4">
            Prête à transformer votre routine beauté ?
          </h3>
          <p className="text-xl text-white mb-8">
            Rejoignez des milliers de femmes qui ont déjà adopté nos soins naturels.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/products">
              <button className="bg-white text-emerald-600 px-8 py-3 rounded-full font-medium hover:bg-gray-100 transition-colors whitespace-nowrap cursor-pointer">
                Commencer maintenant
              </button>
            </Link>
            <button className="border-2 border-white text-white px-8 py-3 rounded-full font-medium hover:bg-white hover:text-emerald-600 transition-colors whitespace-nowrap cursor-pointer">
              Guide personnalisé
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h4 className="text-xl font-bold mb-4" style={{fontFamily: 'Pacifico, serif'}}>
                Beauté Pure
              </h4>
              <p className="text-gray-400 mb-4">
                Votre partenaire beauté pour une peau radieuse et naturellement éclatante.
              </p>
              <div className="flex space-x-4">
                <button className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center hover:bg-emerald-700 transition-colors cursor-pointer">
                  <i className="ri-facebook-fill"></i>
                </button>
                <button className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center hover:bg-emerald-700 transition-colors cursor-pointer">
                  <i className="ri-instagram-fill"></i>
                </button>
                <button className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center hover:bg-emerald-700 transition-colors cursor-pointer">
                  <i className="ri-youtube-fill"></i>
                </button>
              </div>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Produits</h5>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/products" className="hover:text-white transition-colors cursor-pointer">Nettoyants</Link></li>
                <li><Link href="/products" className="hover:text-white transition-colors cursor-pointer">Sérums</Link></li>
                <li><Link href="/products" className="hover:text-white transition-colors cursor-pointer">Crèmes</Link></li>
                <li><Link href="/products" className="hover:text-white transition-colors cursor-pointer">Masques</Link></li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Support</h5>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/contact" className="hover:text-white transition-colors cursor-pointer">Contact</Link></li>
                <li><Link href="/about" className="hover:text-white transition-colors cursor-pointer">À propos</Link></li>
                <li><a href="#" className="hover:text-white transition-colors cursor-pointer">FAQ</a></li>
                <li><a href="#" className="hover:text-white transition-colors cursor-pointer">Livraison</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Newsletter</h5>
              <p className="text-gray-400 mb-4">Recevez nos conseils beauté et nos offres exclusives.</p>
              <div className="flex">
                <input
                  type="email"
                  placeholder="Votre email"
                  className="flex-1 px-4 py-2 rounded-l-full text-gray-800 text-sm"
                />
                <button className="bg-emerald-600 px-6 py-2 rounded-r-full hover:bg-emerald-700 transition-colors whitespace-nowrap cursor-pointer">
                  S'abonner
                </button>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Beauté Pure. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
